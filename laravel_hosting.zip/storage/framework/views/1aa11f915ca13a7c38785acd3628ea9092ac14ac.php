<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/css/bootstrap.css')); ?>">
    <title>Covid 19 ichsan</title>
</head>
<body>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/popper.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.js')); ?>"></script>
    <div class="container">
        <table class="table table-bordered table-striped">
        <tr class="bg-primary">
            <td colspan="4" align="center"><h1>DATA SURVEY COVID-19</h1><a href="/"><input type="button" class="btn btn-info" value="kembali"></a></td>
        </tr>
        <tr class="bg-warning">
            <th>no</th>
            <th>nama</th>
            <th>resiko</th>
            <th>data</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($d->id); ?></td>
            <td><?php echo e($d->nama); ?></td>
            <td><?php echo e($d->resiko); ?></td>
            <td><?php echo e($d->data); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <center><td colspan="4" align="center"><h1>TIDAK ADA DATA</h1></td></center>
        </tr>
        <?php endif; ?>
        </table>
    </div>
</body>
</html>